let id = 0;
let taskList = {};

function createInput(text) {
    let input = document.createElement("input");
    input.setAttribute('value', text);
    input.type = 'text';
    input.disabled = true;
    return input;
}

function createTickButton() {
    let button = document.createElement("button");
    button.classList.add("button");
    button.setAttribute('id', "tick-button");
    let image = document.createElement("img");
    image.classList.add("image");
    image.alt = "tick";
    image.src = "tick.png";
    button.append(image);
    return button;
}
function createEditButton() {
    let button = document.createElement("button");
    button.classList.add("button");
    button.setAttribute('id', "edit-button");
    let image = document.createElement("img");
    image.classList.add("image");
    image.alt = "edit";
    image.src = "edit.png";
    button.append(image);
    return button;
}
function createDeleteButton() {
    let button = document.createElement("button");
    button.classList.add("button");
    button.setAttribute('id', "delete-button");
    let image = document.createElement("img");
    image.classList.add("image");
    image.alt = "delete";
    image.src = "delete.png";
    button.append(image);
    return button;
}

function addItems(e) {
    e.preventDefault();
    const addtext = document.getElementById("add-task").value;
    if (addtext !== '') {
        id += 1;
        taskList[id] = { text: addtext, completed: false };

        let ul = document.getElementById("task-list");
        let li = document.createElement("li");
        li.classList.add("task-item");

        li.append(createInput(taskList[id].text));
        li.append(createTickButton());
        li.append(createEditButton());
        li.append(createDeleteButton());
        ul.append(li);
        console.log(li);
    } else {
        alert("Write Something to ADD!!!");
    }
}

function deleteItems(e) {
    e.preventDefault();
    let ul = document.getElementById("task-list");
    let li = e.target.parentNode.parentNode;
    ul.removeChild(li);
}

function tickItems(e) {
}

function editItems(e) {
}


window.onload = () => {
    document.getElementById("add-button").addEventListener("click", addItems);
    let ul = document.getElementById("task-list");
    if (ul.childElementCount !== 0) {
        console.log(document.getElementById("delete-button"));
        document.getElementById("delete-button").addEventListener("click", deleteItems);
        document.getElementById("tick-button").addEventListener("click", tickItems);
        document.getElementById("edit-button").addEventListener("click", editItems);
    }
}


